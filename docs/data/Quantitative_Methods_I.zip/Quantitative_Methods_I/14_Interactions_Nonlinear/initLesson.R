# The survey data ships inside the lesson folder, so that the lesson works
# with no internet connection in the seminar.
#
# swirl sources this file without changing the working directory, so the path
# has to be built from swirl's own courses directory rather than assumed.

.get_course_path <- function() {
  tryCatch(
    swirl:::swirl_courses_dir(),
    error = function(c) file.path(find.package("swirl"), "Courses")
  )
}

.path2rds <- file.path(
  .get_course_path(),
  "Quantitative_Methods_I",
  "14_Interactions_Nonlinear",
  "swe.rds"
)

swe <- readRDS(.path2rds)

# The trust score from session 10, and a readable version of party closeness.
.trust_items <- c(
  "tr_parl", "tr_govt", "tr_court",
  "tr_sci", "tr_party", "tr_media"
)
swe$trust <- psych::fa(swe[, .trust_items], nfactors = 1, fm = "ml")$scores[, 1]

swe$partisan <- factor(
  swe$pid,
  levels = c(0, 1),
  labels = c("No", "Yes")
)
