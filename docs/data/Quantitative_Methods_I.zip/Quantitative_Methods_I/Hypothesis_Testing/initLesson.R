# The survey data ships inside the lesson folder, so that the lesson works
# with no internet connection in the seminar.
#
# swirl sources this file without changing the working directory, so the path
# has to be built from swirl's own courses directory rather than assumed.

.get_course_path <- function() {
  tryCatch(
    swirl:::swirl_courses_dir(),
    error = function(c) file.path(find.package("swirl"), "Courses")
  )
}

.path2rds <- file.path(
  .get_course_path(),
  "Quantitative_Methods_I",
  "Hypothesis_Testing",
  "swe.rds"
)

swe <- readRDS(.path2rds)

turnout <- readr::read_csv(
  file.path(dirname(.path2rds), "turnout.csv"),
  show_col_types = FALSE
)
turnout <- as.data.frame(turnout)
